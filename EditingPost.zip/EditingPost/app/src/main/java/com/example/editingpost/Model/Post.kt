package com.example.editingpost.Model

data class Post (
    val text: String
)
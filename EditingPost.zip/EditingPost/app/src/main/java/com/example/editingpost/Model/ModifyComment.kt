package com.example.editingpost.Model

data class ModifyComment (
    val text: String
)
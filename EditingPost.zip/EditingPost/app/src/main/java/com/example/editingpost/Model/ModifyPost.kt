package com.example.editingpost.Model

data class ModifyPost (
   val text: String
)
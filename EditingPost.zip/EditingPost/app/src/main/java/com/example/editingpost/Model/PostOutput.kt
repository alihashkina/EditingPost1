package com.example.editingpost.Model

data class PostOutput(
    var id: Int,
    var text: String,
    var user_id: Int
)
package com.example.editingpost.Model

data class Auth (
    val email: String,
    val password: String
)
package com.example.editingpost.Model

data class DataEditingPost (
    val text: String
)
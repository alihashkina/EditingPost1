package com.example.editingpost.Model

data class Token(
    val token:String
)